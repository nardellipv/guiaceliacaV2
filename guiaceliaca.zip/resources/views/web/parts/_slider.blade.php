<section id="header-page" class="header-margin-base">
    <div class="skyline" style="margin-top: -88px;">
        <div data-offset="50" class="p1 parallax"></div>
        <div data-offset="25" class="p2 parallax"></div>
        <div data-offset="15" class="p3 parallax"></div>
        <div data-offset="8" class="p4 parallax"></div>
        <span class="cover"></span>
        <div class="container header-text">
            <div><h1 class="title">Guía celíaca</h1></div>
            <div><h2 class="sub-title">ENCUENTRA COMIDA SIN TACC EN LOS DISTINTOS COMERCIOS ADHERIDOS.</h2></div>
        </div>
    </div>
</section>
{{--<section id="search-box" class="no-margin">--}}
    {{--<div class="container search-container fixed-map">--}}
        {{--<form method="post" action="{{ route('search') }}" enctype="multipart/form-data"--}}
              {{--class="grey-color">--}}
            {{--@csrf--}}
            {{--<div class="search-options sample-page">--}}
                {{--<span class="botton-options"><i class="fa fa-chevron-down"></i> Búsqueda avanzada</span>--}}
                {{--<div class="searcher" style="display: none">--}}
                    {{--<div class="row margin-div">--}}
                        {{--<div class="col-sm-6 col-md-6 margin-bottom">--}}
                            {{--<input class="form-control" type="text" name="keywords" id="keywords"--}}
                                   {{--placeholder="Local"/>--}}
                        {{--</div>--}}
                        {{--<div class="col-sm-6 col-md-6">--}}
                            {{--<select class="dropdown" name="provinices" data-settings='{"cutOff": 5}'>--}}
                                {{--<option value="">-- Provincias --</option>--}}
                                {{--@foreach($provinces as $province)--}}
                                    {{--<option value="{{ $province->id }}">{{ $province->name }}</option>--}}
                                {{--@endforeach--}}
                            {{--</select>--}}
                        {{--</div>--}}
                    {{--</div>--}}
                    {{--<div class="row filter hide-filter hidden-xs hidden-sm">--}}
                        {{--@foreach($characteristics as $characteristic)--}}
                            {{--<div class="col-xs-6 col-sm-4 col-md-3">--}}
                                {{--<input class="labelauty" name="characteristic[]" value="{{ $characteristic->id }}"--}}
                                       {{--type="checkbox" data-labelauty="{{ $characteristic->name }}">--}}
                            {{--</div>--}}
                        {{--@endforeach--}}

                        {{--@foreach($payments as $payment)--}}
                            {{--<div class="col-xs-6 col-sm-4 col-md-3">--}}
                                {{--<input class="labelauty" type="checkbox" name="payment[]" value="{{ $payment->id }}"--}}
                                       {{--data-labelauty="{{ $payment->name }}">--}}
                            {{--</div>--}}
                        {{--@endforeach--}}

                    {{--</div>--}}
                    {{--<div class="margin-div footer">--}}
                        {{--<button type="button" class="btn btn-default more-button hidden-xs hidden-sm">Más Flitros--}}
                        {{--</button>--}}
                        {{--<button type="submit" class="btn btn-default search-button">Buscar</button>--}}
                    {{--</div>--}}
                {{--</div>--}}
            {{--</div>--}}
        {{--</form>--}}
    {{--</div>--}}
{{--</section>--}}
