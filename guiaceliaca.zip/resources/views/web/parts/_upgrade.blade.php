<div class="alert with-icon alert-info" role="alert"><i class="icon fa fa-info"></i> Aumentá la exposición de tu negocio
    dentro de Guía Celíaca. Click <a href="{{ route('faq.packets') }}" target="_blank">aquí</a> para precios y ayuda.
</div>
<script type='text/javascript'>
    (function () {
        if (window.localStorage) {
            if (!localStorage.getItem('firstLoad')) {
                localStorage['firstLoad'] = true;
                window.location.reload();
            }
            else
                localStorage.removeItem('firstLoad');
        }
    })();
</script>