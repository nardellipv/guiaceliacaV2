<p><img src="https://guiaceliaca.com.ar/images/img-logo.png" alt="" width="178" height="145" /></p>
<hr />
<p>Hola,</p>
<p><strong>Nombre Comercio:</strong> {{ $commerce->name }}</p>
<p><strong>Teléfono Comercio:</strong> {{ $commerce->phone }}</p>
<p><strong>EMail:&nbsp;</strong> {{ $commerce->user->email }}</p>
<p><strong>Cuenta:</strong> {{ $account->name }}</p>
<p>Saludos,&nbsp;</p>
<p>Gu&iacute;a Cel&iacute;aca</p>
<hr />
<p><sub><span style="color: #ff0000;">Este mail fue generado autom&aacute;ticamente, por favor no responda este email.</span></sub></p>